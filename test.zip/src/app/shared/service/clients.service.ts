import { Injectable } from '@angular/core';
import {OAuthService} from "angular-oauth2-oidc";
import {HttpClient} from "./custom-http.service";

@Injectable()
export class ClientsService {

  constructor(private httpClient: HttpClient){

  }

  getClients(){
    return this.httpClient.get("Clients");
  }
}
