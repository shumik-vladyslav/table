import {Component, ElementRef, Input, OnInit, ViewChild} from '@angular/core';
import {Observable} from "rxjs/Observable";
import "rxjs/add/observable/fromEvent";
import "rxjs/add/operator/debounceTime";
import "rxjs/add/operator/distinctUntilChanged";
import {JwksValidationHandler, OAuthService} from "angular-oauth2-oidc";
import {authConfig} from "../../app.module";
import {ClientsService} from "../../shared/service/clients.service";

export interface Man{
  name: string,
  joining_date:string,
  age: number
}

@Component({
  selector: 'app-table',
  templateUrl: './test-table.component.html',
  styleUrls: ['./test-table.component.css']
})

export class TableComponent implements OnInit {
  tableSource;

  constructor() {}

  @Input() data;
  @Input() options;
  @ViewChild('filter') filter: ElementRef;

  ngOnInit() {
    Observable.fromEvent(this.filter.nativeElement, 'keyup')
      .debounceTime(150)
      .distinctUntilChanged()
      .subscribe(() => {
        this.tableSource = this.data.filter(o => o.name.toLowerCase().includes(this.filter.nativeElement.value.toLowerCase()));
      });
  }

}
