import { Component, OnInit } from '@angular/core';
import {ClientsService} from "../../shared/service/clients.service";

@Component({
  selector: 'app-clients',
  templateUrl: './clients.component.html',
  styleUrls: ['./clients.component.css']
})
export class ClientsComponent implements OnInit {
  tableData;
  tableOptions = {
    "name": "Name",
    "ce-id": "C.E. ID",
    "qr": "QB Red ID",
  };
  constructor(private clientsService: ClientsService) {
    clientsService.getClients().subscribe((data) => {
      this.tableData = data;
    });
  }

  ngOnInit() {
  }

}
